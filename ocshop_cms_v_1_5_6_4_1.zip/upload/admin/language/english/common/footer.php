<?php
// Text
$_['text_footer'] = '<a href="http://ocshop.info">OCSHOP.CMS</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.<br />Version %s';
?>