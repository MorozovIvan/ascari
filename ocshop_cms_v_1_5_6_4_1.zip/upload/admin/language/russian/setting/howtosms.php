<?php
// Heading
$_['heading_title'] = 'Инструкция настройки SMSc.ru';
?>