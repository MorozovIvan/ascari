<?php
$_['lang_openbay_new']              = 'Создать объявление';
$_['lang_openbay_edit']             = 'Просмотр / Редактирование объявления';
$_['lang_openbay_fix']              = 'Исправить ошибки';
$_['lang_openbay_processing']       = 'Выполняется';

$_['lang_amazonus_saved']           = 'Сохранено (не загружено)';
$_['lang_amazon_saved']             = 'Сохранено (не загружено)';
$_['lang_play_pending_new']         = 'Ожидает (новый)';
$_['lang_play_pending_updated']     = 'Ожидает (обновленный)';
$_['lang_play_warning']             = 'Предупреждения';
$_['lang_play_pending_delete']      = 'Ожидает удаления';
$_['lang_play_stock_updating']      = 'Обновление запасов';

$_['lang_markets']                  = 'Рынки';
$_['lang_bulk_btn']                 = 'Массовая загрузка eBay';

$_['lang_marketplace']              = 'Marketplace';
$_['lang_status']                   = 'Статус';
$_['lang_option']                   = 'Вариант';