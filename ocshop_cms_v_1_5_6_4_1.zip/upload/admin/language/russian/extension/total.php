<?php
// Heading
$_['heading_title']     = 'Учитывать в заказе';

// Text
$_['text_install']      = 'Установить';
$_['text_uninstall']    = 'Удалить';

// Column
$_['column_name']       = 'Учитывать в заказе';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У Вас нет прав для управления этим модулем!';
?>