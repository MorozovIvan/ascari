<?php
// Heading
$_['heading_title']     	= 'SEO Менеджер';

// Text
$_['text_success']      	= 'SEO URL успешно обновлены!';
$_['text_success_clear'] 	= 'Кэш SEO URL успешно сброшен!';
$_['text_default']      	= 'По умолчанию';
$_['text_module']			= 'Модули';
$_['button_clear_cache'] 	= 'Сбросить кэш';

// Column
$_['column_query']       	= 'Ссылка';
$_['column_keyword']       	= 'SEO URL';
$_['column_action']     	= 'Действие';

// Error
$_['error_permission']  	= 'У Вас недостаточно прав для изменения SEO Менеджер!';
?>