<?php
// Text
$_['text_footer'] = '<a href="http://ocshop.info">OCSHOP.CMS</a> &copy; 2009-' . date('Y') . ' <a href="http://forum.ocshop.info">Форум Поддержки</a><br />All Rights Reserved. Версия %s';
?>