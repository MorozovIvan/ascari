<?php

// Heading
$_['heading_title'] = 'Кнопка PayPal Express Checkout';

$_['text_module'] = 'Модули';
$_['text_success'] = 'Модуль PP Layout успешно изменен!';
$_['text_content_top'] = 'Верх страницы';
$_['text_content_bottom'] = 'Низ страницы';
$_['text_column_left'] = 'Левая колонка';
$_['text_column_right'] = 'Правая колонка';

$_['entry_layout'] = 'Макет:';
$_['entry_position'] = 'Позиция:';
$_['entry_status'] = 'Статус:';
$_['entry_sort_order'] = 'Порядок сортировки:';

$_['error_permission'] = 'У вас нет прав для редактирования модуля!';